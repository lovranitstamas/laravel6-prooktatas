<?php $__env->startSection('content'); ?>

    <h1>Hello admin: <?php echo e(auth('admin')->user()->name); ?></h1>

    <?php if($errors->first('email')): ?>
        <h2 style="color: red"><?php echo e($errors->first('email')); ?></h2>
    <?php endif; ?>
    <form action="<?php echo e(route('admin.logout')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <button type="submit" class="btn btn-primary m-3">Kilépés</button>
    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp7\htdocs\03_Authentication\resources\views/admin/dashboard/index.blade.php ENDPATH**/ ?>