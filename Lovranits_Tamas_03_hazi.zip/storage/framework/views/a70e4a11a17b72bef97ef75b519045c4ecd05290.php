<?php $__env->startSection('content'); ?>

    <h4>Belépés</h4>
    <form action="<?php echo e(route('login.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            Email:
            <input type="text" name="email" value="<?php echo e(old('email')); ?>" class="form-control">
        </div>

        <div class="form-group">
            Password:
            <input type="password" name="password" class="form-control">
            <br><br>
            <button type="submit" class="btn btn-primary">Belépés</button>
        </div>
    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout.application', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\prookt\laravel\03_Authentication\resources\views/frontend/auth/create.blade.php ENDPATH**/ ?>