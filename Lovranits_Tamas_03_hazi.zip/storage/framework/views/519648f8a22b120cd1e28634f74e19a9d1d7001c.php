<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<?php echo $__env->make('frontend.layout.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>
<?php echo $__env->make('frontend.layout.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('content'); ?>
<?php echo $__env->yieldContent('footer'); ?>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\prookt\laravel\virtualizacio\resources\views/frontend/layout/application.blade.php ENDPATH**/ ?>