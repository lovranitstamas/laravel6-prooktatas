<?php $__env->startSection('content'); ?>

    <h4>Regisztráció</h4>

    <?php if(session()->has('message')): ?>
        <h3><?php echo e(session('message')); ?></h3>
    <?php else: ?>
        <?php echo $__env->make('frontend.customers.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.application', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp7\htdocs\03_Authentication\resources\views/frontend/customers/create.blade.php ENDPATH**/ ?>