<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<link href="/css/app.css" rel="stylesheet">
<?php echo $__env->make('frontend.layout.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>

<?php echo $__env->make('frontend.layout.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container mt-5">
    <?php echo $__env->yieldContent('content'); ?>
    <?php echo $__env->yieldContent('footer'); ?>
</div>

<?php echo $__env->make('frontend.layout.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>
</html>
<?php /**PATH C:\xampp7\htdocs\Virtualizacio\resources\views/frontend/layout/application.blade.php ENDPATH**/ ?>