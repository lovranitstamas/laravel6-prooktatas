<script
        src="https://code.jquery.com/jquery-2.2.4.min.js"
        integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44="
        crossorigin="anonymous"></script>

<script src="/js/script.js"></script>
<?php /**PATH C:\xampp\htdocs\prookt\laravel\03_Authentication\resources\views/frontend/layout/scripts.blade.php ENDPATH**/ ?>