<?php $__env->startSection('content'); ?>

    <?php if(session()->has('message')): ?>
        <h3><?php echo e(session('message')); ?></h3>
    <?php else: ?>
    <h4>Módosítás</h4>
    <form action="<?php echo e(route('customers.update', $customer->id)); ?>" method="POST">
        <input type="hidden" name="_method" value="put">
        <?php echo csrf_field(); ?>

        Név:
        <input type="text" name="name" value="<?php echo e($customer->name); ?>" class="<?php echo e($errors->first('name') ? 'has-error': ''); ?>">
        <?php if($errors->first('name')): ?>
            <p style="color:red">
                <?php echo e($errors->first('name')); ?>

            </p>
        <?php endif; ?>

        <br>
        Email:
        <input type="text" name="email" value="<?php echo e($customer->email); ?>">
        <?php if($errors->first('email')): ?>
            <p style="color:red">
                <?php echo e($errors->first('email')); ?>

            </p>
        <?php endif; ?>

        <br>
        Leírás:
        <input type="text" name="leiras" value="<?php echo e($customer->leiras); ?>">
        <?php if($errors->first('leiras')): ?>
            <p style="color:red">
                <?php echo e($errors->first('leiras')); ?>

            </p>
        <?php endif; ?>

        <br>
        Jelszó:
        <input type="password" name="password">
        <br>
        Jelszó újra:
        <input type="password" name="password_confirmation">
        <?php if($errors->first('password')): ?>
            <p style="color:red">
                <?php echo e($errors->first('password')); ?>

            </p>
        <?php endif; ?>

        <br>
        <input type="submit" value="Módosítás">


    </form>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <footer>
        Footer
    </footer>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout.application', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\prookt\laravel\virtualizacio\resources\views/frontend/customers/show.blade.php ENDPATH**/ ?>