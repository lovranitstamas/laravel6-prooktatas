

<a href="<?php echo e(route('customers.index')); ?>">Index</a> |
<a href="<?php echo e(route('customers.indexByFilter')); ?>">Index by szűrés</a> |
<a href="<?php echo e(route('customers.create')); ?>">Regisztráció</a> |

<?php if(auth()->guard('customer')->check()): ?>
    Belépve: <?php echo e(auth()->guard('customer')->user()->name); ?>

    <form action="<?php echo e(route('login.destroy')); ?>" method="POST">
        <input type="hidden" name="_method" value="DELETE">
        <?php echo csrf_field(); ?>
        <button type="submit" class="btn btn-primary m-3">Kilépés</button>
    </form>
<?php else: ?>
    <a href="<?php echo e(route('login.create')); ?>">Belépés</a> |
<?php endif; ?>


<?php /**PATH C:\xampp7\htdocs\03_Authentication\resources\views/frontend/layout/menu.blade.php ENDPATH**/ ?>