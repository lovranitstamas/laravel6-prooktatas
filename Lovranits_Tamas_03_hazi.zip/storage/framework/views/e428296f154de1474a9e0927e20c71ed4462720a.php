<form action="<?php echo e(route('customers.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>

    Név:
    <input type="text" name="name" value="<?php echo e(old('name')); ?>" class="<?php echo e($errors->first('name') ? 'has-error': ''); ?>">
    <?php if($errors->first('name')): ?>
        <p style="color:red">
            <?php echo e($errors->first('name')); ?>

        </p>
    <?php endif; ?>

    <br>
    Email:
    <input type="text" name="email" value="<?php echo e(old('email')); ?>">
    <?php if($errors->first('email')): ?>
        <p style="color:red">
            <?php echo e($errors->first('email')); ?>

        </p>
    <?php endif; ?>

    <br>
    Leírás:
    <input type="text" name="leiras" value="<?php echo e(old('leiras')); ?>">
    <?php if($errors->first('leiras')): ?>
        <p style="color:red">
            <?php echo e($errors->first('leiras')); ?>

        </p>
    <?php endif; ?>

    <br>
    Jelszó:
    <input type="password" name="password">
    <?php if($errors->first('password')): ?>
        <p style="color:red">
            <?php echo e($errors->first('password')); ?>

        </p>
    <?php endif; ?>

    <br>
    Jelszó újra:
    <input type="password" name="password_confirmation">

    <label>
        <input type="checkbox" name="terms" value="1" <?php echo e(old('terms') ? 'checked': ''); ?>>
        Elfogadok mindent
    </label>

    <br>
    <input type="submit" value="Register">


</form>
<?php /**PATH C:\xampp\htdocs\prookt\laravel\virtualizacio\resources\views/frontend/customers/form.blade.php ENDPATH**/ ?>