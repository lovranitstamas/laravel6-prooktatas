

<a href="<?php echo e(route('customers.index')); ?>">Index</a> |
<a href="<?php echo e(route('customers.indexByFilter')); ?>">Index by szűrés</a> |
<a href="<?php echo e(route('customers.create')); ?>">Regisztráció</a> |
<a href="<?php echo e(route('login.create')); ?>">Belépés</a> |



<?php /**PATH C:\xampp7\htdocs\Virtualizacio\resources\views/frontend/layout/menu.blade.php ENDPATH**/ ?>