<?php $__env->startSection('content'); ?>

    <h4>Ügyfelek</h4>

    <?php if(session()->has('message')): ?>
        <h3><?php echo e(session('message')); ?></h3>
    <?php endif; ?>

    <form action="<?php echo e(route('customers.indexByFilter')); ?>" method="GET">
        <table class="table table-striped">
            <thead>
            <tr>
                <td>#</td>
                <td>Név</td>
                <td>E-mail</td>
                <td>Utolsó modosítás dátuma dátuma</td>
                <td>Keresés</td>
            </tr>
            </thead>
            <tbody>
            <tr>
                <td><input type="text" name="search[id]" value="<?php echo e(request()->input('search.id')); ?>"></td>
                <td><input type="text" name="search[name]" value="<?php echo e(request()->input('search.name')); ?>"></td>
                <td><input type="text" name="search[email]" value="<?php echo e(request()->input('search.email')); ?>"></td>
                <td><input type="text" name="search[updated_at]" value="<?php echo e(request()->input('search.updated_at')); ?>"></td>
                <td><input type="submit" value="Keresés"></td>
            </tr>

            <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr id="customer-<?php echo e($customer->id); ?>">
                    <td><?php echo e($customer->id); ?></td>
                    <td><?php echo e($customer->name); ?></td>
                    <td><?php echo e($customer->email); ?></td>
                    <td><?php echo e($customer->lastUpdated()); ?></td>
                    <td>
                        <button class="btn btn-danger del-button"
                                data-token="<?php echo e(csrf_token()); ?>"
                                data-id="<?php echo e($customer->id); ?>"
                                data-url="<?php echo e(route('customers.destroyDestroyWithJson', $customer->id)); ?>">
                            Törlés
                        </button>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </form>
<?php $__env->stopSection(); ?> 

<?php $__env->startSection('footer'); ?>
    <footer>
        Footer
    </footer>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout.application', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp7\htdocs\03_Authentication\resources\views/frontend/customers/indexByFilter.blade.php ENDPATH**/ ?>