

<a href="<?php echo e(route('customers.index')); ?>">Index</a> |
<a href="<?php echo e(route('customers.create')); ?>">Regisztráció</a> |



<?php /**PATH C:\xampp\htdocs\prookt\laravel\virtualizacio\resources\views/frontend/layout/menu.blade.php ENDPATH**/ ?>