<form action="<?php echo e($customer->id ? route('customers.update', $customer->id) : route('customers.store')); ?>" method="POST">
    <?php if($customer->id): ?>
        <input type="hidden" name="_method" value="PUT">

        <div class="form-group">
            #:
            <input type="text" name="id" value="<?php echo e($customer->id); ?>" disabled class="form-control">
        </div>
    <?php endif; ?>

    <?php echo csrf_field(); ?>

    <div class="form-group">
        Név:
        <input type="text" name="name" value="<?php echo e(old('name') ?: $customer->name); ?>"
               class="<?php echo e($errors->first('name') ? 'has-error': ''); ?> form-control">
        <?php if($errors->first('name')): ?>
            <p style="color:red">
                <?php echo e($errors->first('name')); ?>

            </p>
        <?php endif; ?>
    </div>

    <div class="form-group">
        Email:
        <input type="text" name="email" value="<?php echo e(old('email') ?: $customer->email); ?>" class="form-control">
        <?php if($errors->first('email')): ?>
            <p style="color:red">
                <?php echo e($errors->first('email')); ?>

            </p>
        <?php endif; ?>
    </div>

    <div class="form-group">
        Leírás:
        <input type="text" name="description" value="<?php echo e(old('description') ?: $customer->description); ?>" class="form-control">
        <?php if($errors->first('description')): ?>
            <p style="color:red">
                <?php echo e($errors->first('description')); ?>

            </p>
        <?php endif; ?>
    </div>

    <div class="form-group">
        Jelszó:
        <input type="password" name="password" class="form-control">
        <?php if($errors->first('password')): ?>
            <p style="color:red">
                <?php echo e($errors->first('password')); ?>

            </p>
        <?php endif; ?>
    </div>

    <div class="form-group">
        Jelszó újra:
        <input type="password" name="password_confirmation" class="form-control">
    </div>


    <?php if(!$customer->id): ?>
        <div class="form-group">
            <label>
                <input type="checkbox" name="terms" value="1" <?php echo e(old('terms') ? 'checked': ''); ?>>
                Elfogadok mindent
            </label>
            <?php if($errors->first('terms')): ?>
                <p style="color:red">
                    <?php echo e($errors->first('terms')); ?>

                </p>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <div class="form-group">
        <input type="submit" value="<?php echo e(!$customer->id ? 'Register' : 'Modify'); ?>" class="btn btn-primary">
    </div>

</form>
<?php /**PATH C:\xampp\htdocs\prookt\laravel\03_Authentication\resources\views/frontend/customers/form.blade.php ENDPATH**/ ?>