<?php $__env->startSection('content'); ?>

    <h4>Megtekintés</h4>

    <div class="form-group">
        Név:
        <input type="text" name="name" value="<?php echo e($customer->name); ?>" disabled class="form-control">
    </div>

    <div class="form-group">
        Email:
        <input type="text" name="email" value="<?php echo e($customer->email); ?>" disabled class="form-control">
    </div>

    <div class="form-group">
        Leírás:
        <input type="text" name="description" value="<?php echo e($customer->description); ?>" disabled class="form-control">
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <footer>
        Footer
    </footer>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout.application', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp7\htdocs\Virtualizacio\resources\views/frontend/customers/show.blade.php ENDPATH**/ ?>