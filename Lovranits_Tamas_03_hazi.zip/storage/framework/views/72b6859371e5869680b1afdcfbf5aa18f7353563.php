<meta charset="utf-8">
<?php /**PATH C:\xampp\htdocs\prookt\laravel\03_Authentication\resources\views/frontend/layout/head.blade.php ENDPATH**/ ?>