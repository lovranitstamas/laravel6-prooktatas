<form action="<?php echo e(route('customers.note.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>

    <input type="hidden" name="user_id" value="<?php echo e($customer->id); ?>">

    <div class="form-group">
        Tartalom:
        <textarea cols="10" rows="15" name="content" class="form-control"></textarea>
        <?php if($errors->first('content')): ?>
            <p style="color:red">
                <?php echo e($errors->first('content')); ?>

            </p>
        <?php endif; ?>
    </div>

    <div class="form-group">
        <input type="submit" value="Mentés" class="btn btn-primary">
    </div>

</form>
<?php /**PATH C:\xampp\htdocs\prookt\laravel\03_Authentication\resources\views/frontend/auth/notes/form.blade.php ENDPATH**/ ?>