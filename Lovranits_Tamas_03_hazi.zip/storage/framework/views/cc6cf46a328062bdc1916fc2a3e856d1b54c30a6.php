<?php $__env->startSection('content'); ?>

    <h4>Ügyfelek</h4>

    <?php if(session()->has('message')): ?>
        <h3><?php echo e(session('message')); ?></h3>
    <?php endif; ?>

    <table class="table table-striped">
        <thead>
        <tr>
            <td>#</td>
            <td>Név</td>
            <td>E-mail</td>
            <td>Leírás</td>
            <td>Regisztrációs dátuma</td>
            <td>Utolsó modosítás dátuma dátuma</td>
            <td>Megtekintés</td>
            <td>Módosítás</td>
            <td>Hagyományos törlés</td>
            <td>Json alapú törlés</td>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr id="customer-<?php echo e($customer->id); ?>">
                <td><?php echo e($customer->id); ?></td>
                <td><?php echo e($customer->name); ?></td>
                <td><?php echo e($customer->email); ?></td>
                <td><?php echo e($customer->description); ?></td>
                <td><?php echo e($customer->created_at); ?></td>
                <td><?php echo e($customer->lastUpdated()); ?></td>
                <td><a href="<?php echo e(route('customers.show', ['id' => $customer->id])); ?>">Megtekintés</a></td>
                <td><a href="<?php echo e(route('customers.edit', ['id' => $customer->id])); ?>">Módosítás</a></td>
                <td>
                    <form action="<?php echo e(route('customers.destroy', $customer->id)); ?>" method="POST">
                        <input type="hidden" name="_method" value="delete">
                        <?php echo csrf_field(); ?>
                        <input type="submit" name="button" value="Törlés">
                    </form>
                </td>
                <td>
                    <button class="btn btn-danger del-button"
                            data-token="<?php echo e(csrf_token()); ?>"
                            data-id="<?php echo e($customer->id); ?>"
                            data-url="<?php echo e(route('customers.destroyDestroyWithJson', $customer->id)); ?>">
                        Törlés
                    </button>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <h4>Jegyzetek</h4>
    <table class="table table-striped">
        <thead>
        <tr>
            <td>#</td>
            <td>Felhasználó</td>
            <td>Jegyzet</td>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $notes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($note->id); ?></td>
                <td><?php echo e($note->customer->name); ?></td>
                <td><?php echo e($note->content); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

<?php $__env->stopSection(); ?> 

<?php $__env->startSection('footer'); ?>
    <footer>
        Footer
    </footer>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout.application', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\prookt\laravel\03_Authentication\resources\views/frontend/customers/index.blade.php ENDPATH**/ ?>