<?php $__env->startSection('content'); ?>
    Ez itt a <?php echo e($page); ?> oldal
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout.application', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp7\htdocs\03_Authentication\resources\views/frontend/pages/show.blade.php ENDPATH**/ ?>