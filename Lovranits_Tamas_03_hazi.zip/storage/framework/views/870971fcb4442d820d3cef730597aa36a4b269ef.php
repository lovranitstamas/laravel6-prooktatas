<?php $__env->startSection('content'); ?>

    <h1>Kezdőlap</h1>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('pages.register')); ?>" method="POST">
        <!--<input type="hidden" name="_method" value="delete">-->
        <?php echo csrf_field(); ?>
        Név:
        <input type="text" name="name" value="<?php echo e(old('name')); ?>">
        <?php if($errors->first('name')): ?>
            <p style="color:red">
                <?php echo e($errors->first('name')); ?>

            </p>
        <?php endif; ?>
        <br>
        Jelszó:
        <input type="password" name="password">
        <?php if($errors->first('password')): ?>
            <p style="color:red">
                <?php echo e($errors->first('password')); ?>

            </p>
        <?php endif; ?>
        <br>
        Jelszó újra:
        <input type="password" name="password_confirmation">
        <br>
        <input type="submit" value="Register">
    </form>

    <?php if($i==3): ?>
        Az $i értéke: <?php echo e($i); ?>

    <?php else: ?>
        Az $i értéke: <?php echo e($i); ?>

    <?php endif; ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer'); ?>
    <footer>
        Footer
    </footer>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout.application', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp7\htdocs\03_Authentication\resources\views/index.blade.php ENDPATH**/ ?>