<meta charset="utf-8">
<?php /**PATH C:\xampp7\htdocs\Virtualizacio\resources\views/frontend/layout/head.blade.php ENDPATH**/ ?>