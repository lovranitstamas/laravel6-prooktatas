<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

/*Route::get('/', function () {
    return view('welcome');
});*/

Route::namespace('Admin')->group(function () {
    Route::namespace('Auth')->group(function () {
        Route::get('/admin/login', 'LoginController@showLoginForm')->name('admin.login.create');
        Route::post('/admin/login', 'LoginController@login')->name('admin.login.store');
        Route::post('/logout', 'LoginController@logout')->name('admin.logout');
    });

    Route::middleware('admin_auth')->group(function () {
        Route::get('/admin', 'DashboardController@index')->name('admin.dashboard');

    });
});

//Customer auth routes
Route::get('/login', 'CustomersAuthController@create')->name('login.create');
Route::post('/login', 'CustomersAuthController@store')->name('login.store');


//Customer routes
Route::middleware('customer_auth')->group(function () {
    Route::get('/customers', 'CustomersController@index')->name('customers.index');
    Route::delete('/logout', 'CustomersAuthController@destroy')->name('login.destroy');

    Route::get('/note', 'CustomersAuthNoteController@create')->name('customers.note.create');
    Route::post('/note', 'CustomersAuthNoteController@store')->name('customers.note.store');
});
//Route::get('/customers', 'CustomersController@index')->name('customers.index');
Route::get('/customersByFilter', 'CustomersController@indexByFilter')->name('customers.indexByFilter');


Route::get('/registration', 'CustomersController@create')->name('customers.create');
Route::post('/registration', 'CustomersController@store')->name('customers.store');


Route::get('/customer/{id}/modify', 'CustomersController@edit')->name('customers.edit');
Route::put('/customer/{id}/modify', 'CustomersController@update')->name('customers.update');

Route::get('/customer/{id}', 'CustomersController@show')->name('customers.show');
Route::delete('/customer/{id}', 'CustomersController@destroy')->name('customers.destroy');
Route::delete('/customer/{id}/json', 'CustomersController@destroyWithJson')->name('customers.destroyDestroyWithJson');


//Route::delete('/fiok-torles');

Route::get('/lista', 'CustomersController@index')->name('customers.index2');
Route::get('/customer', 'CustomersController@newCustomer')->name('customers.newCustomer');

Route::get('/', 'PagesController@index')->name('index');
//Route::get('/{page}', 'PagesController@show')->name('pages.show');
Route::post('/pageRegister', 'PagesController@register')->name('pages.register');
