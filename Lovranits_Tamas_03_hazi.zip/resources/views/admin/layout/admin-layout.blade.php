<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<link href="/css/app.css" rel="stylesheet">

<body>

<div class="container mt-5">
    <h3>Admin</h3>
    @yield('content')

</div>


</body>
</html>
