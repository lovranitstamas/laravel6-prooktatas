{{--<a href="{{route('index')}}">Kezdőlap</a>
|
<a href="{{route('pages.show', ['page' => 'contact'])}}">Kontakt</a>
<a href="{{route('pages.show', ['page' => 'gallery'])}}">Gallery</a>--}}

<a href="{{route('customers.index')}}">Index</a> |
<a href="{{route('customers.indexByFilter')}}">Index by szűrés</a> |
<a href="{{route('customers.create')}}">Regisztráció</a> |

@if(auth()->guard('customer')->check())
    <a href="{{route('customers.note.create')}}">Jegyzet készítése</a> |
    Belépve: {{auth()->guard('customer')->user()->name }}
    <form action="{{route('login.destroy')}}" method="POST">
        <input type="hidden" name="_method" value="DELETE">
        @csrf
        <button type="submit" class="btn btn-primary m-3">Kilépés</button>
    </form>
@else
    <a href="{{route('login.create')}}">Belépés</a> |
@endif


