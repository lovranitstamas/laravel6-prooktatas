<form action="{{route('customers.note.store')}}" method="POST">
    @csrf

    <input type="hidden" name="user_id" value="{{$customer->id}}">

    <div class="form-group">
        Tartalom:
        <textarea cols="10" rows="15" name="content" class="form-control"></textarea>
        @if($errors->first('content'))
            <p style="color:red">
                {{$errors->first('content')}}
            </p>
        @endif
    </div>

    <div class="form-group">
        <input type="submit" value="Mentés" class="btn btn-primary">
    </div>

</form>
