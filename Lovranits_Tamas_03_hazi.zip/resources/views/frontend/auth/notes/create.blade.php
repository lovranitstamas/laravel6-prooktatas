@extends('frontend.layout.application')

@section('content')

    <h4>Jegyzet kezelés</h4>

    @if(session()->has('message'))
        <h3>{{session('message')}}</h3>
    @else
        @include('frontend.auth.notes.form')
    @endif
@stop
