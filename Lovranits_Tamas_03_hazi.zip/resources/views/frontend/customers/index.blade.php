@extends('frontend.layout.application')

@section('content')

    <h4>Ügyfelek</h4>

    @if(session()->has('message'))
        <h3>{{session('message')}}</h3>
    @endif

    <table class="table table-striped">
        <thead>
        <tr>
            <td>#</td>
            <td>Név</td>
            <td>E-mail</td>
            <td>Leírás</td>
            <td>Regisztrációs dátuma</td>
            <td>Utolsó modosítás dátuma dátuma</td>
            <td>Megtekintés</td>
            <td>Módosítás</td>
            <td>Hagyományos törlés</td>
            <td>Json alapú törlés</td>
        </tr>
        </thead>
        <tbody>
        @foreach($customers as $customer)
            <tr id="customer-{{$customer->id}}">
                <td>{{$customer->id}}</td>
                <td>{{$customer->name}}</td>
                <td>{{$customer->email}}</td>
                <td>{{$customer->description}}</td>
                <td>{{$customer->created_at}}</td>
                <td>{{$customer->lastUpdated()}}</td>
                <td><a href="{{route('customers.show', ['id' => $customer->id])}}">Megtekintés</a></td>
                <td><a href="{{route('customers.edit', ['id' => $customer->id])}}">Módosítás</a></td>
                <td>
                    <form action="{{route('customers.destroy', $customer->id)}}" method="POST">
                        <input type="hidden" name="_method" value="delete">
                        @csrf
                        <input type="submit" name="button" value="Törlés">
                    </form>
                </td>
                <td>
                    <button class="btn btn-danger del-button"
                            data-token="{{csrf_token()}}"
                            data-id="{{$customer->id}}"
                            data-url="{{route('customers.destroyDestroyWithJson', $customer->id)}}">
                        Törlés
                    </button>
                </td>
            </tr>
        @endforeach
        </tbody>
    </table>

    <h4>Jegyzetek</h4>
    <table class="table table-striped">
        <thead>
        <tr>
            <td>#</td>
            <td>Felhasználó</td>
            <td>Jegyzet</td>
        </tr>
        </thead>
        <tbody>
        @foreach($notes as $note)
            <tr>
                <td>{{$note->id}}</td>
                <td>{{$note->customer->name}}</td>
                <td>{{$note->content}}</td>
            </tr>
        @endforeach
        </tbody>
    </table>

@endsection {{-- @stop--}}

@section('footer')
    <footer>
        Footer
    </footer>
@endsection
