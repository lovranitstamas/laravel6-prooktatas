@extends('frontend.layout.application')

@section('content')
    Ez itt a {{$page}} oldal
@endsection
