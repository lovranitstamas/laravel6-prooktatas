#!/usr/bin/env bash

# Clear The Old Nginx Sites

rm -f /etc/nginx/sites-enabled/*
rm -f /etc/nginx/sites-available/*
