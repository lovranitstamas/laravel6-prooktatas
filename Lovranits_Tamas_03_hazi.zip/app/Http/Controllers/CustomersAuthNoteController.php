<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Customer;
use App\Models\Note;

class CustomersAuthNoteController extends Controller
{
    public function create()
    {

        if (\Auth::guard('customer')->check()) {
            $customer = new Customer();
            $customer->id = \Auth::guard('customer')->user()->id;

            return view('frontend.auth.notes.create')->with('customer', $customer);
        }

        return redirect()->back();
    }

    public function store(Request $request)
    {
        $this->validate($request, [
            'content' => 'required|min:20'
        ]);

        $note = new Note();

        $note->setAttributes($request->all());
        $note->save();

        session()->flash('message', 'Köszönjük a bejegyzést');

        return redirect()->back();

    }

}
