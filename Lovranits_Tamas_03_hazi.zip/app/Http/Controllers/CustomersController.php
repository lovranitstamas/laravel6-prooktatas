<?php

namespace App\Http\Controllers;

use App\Models\Note;
use Illuminate\Http\Request;
use App\Models\Customer;

class CustomersController extends Controller
{

    //list by filter
    public function indexByFilter(Request $request)
    {

        $search = $request->input('search'); //array
        $customers = Customer::freshRegister()->get();

        return view('frontend.customers.indexByFilter')->with('customers', $customers);
    }

    //list
    public function index()
    {
        $customers = Customer::all();
        $notes = Note::all();

        //return view('frontend.customers.index', [])
        return view('frontend.customers.index')
            ->with('customers', $customers)
            ->with('notes', $notes);

        /*Customer::where('name', 'LIKE', '%Horvath%')
            ->orWhere('email', 'LIKE', '%Horvath%') //orWhere, elég ha egy feltétel teljesül
            ->orderBy('name', 'asc')
            ->skip(5) //1-5 kihagyja
            ->limit(10) // 10et ad vissza
            ->get();  //Collectionként adja vissza
        //->count(); Hány darab van

        //utolsó elem:
        Customer::orderBy('id', 'desc')->first();

        //10nél több az idja ÉS horvathnak hívják  VAGY 02-15.én regisztrált
        Customer::where(function($query){
          $query->where('id','>', 10)->where('name', 'LIKE', 'Horvath');
        })->orWhere('created_at', '=', '2021-02-15')
        ->get();

        Customer::whereBetween('created_at', ['2021-02-05', '2021-02-12']);

        */

    }

    //show create form
    public function create()
    {
        $customer = new Customer();

        return view('frontend.customers.create')->with('customer', $customer);
    }

    //save new registration
    public function store(Request $request)
    {
        $this->validate($request, [
            'name' => 'required',
            'email' => 'required|email|unique:customers,email',
            'description' => 'required',
            'password' => 'required|confirmed',
            'terms' => 'accepted'
        ]);

        $customer = new Customer();
        /*$customer->name = $request->input('name');
        $customer->email = $request->input('email');
        $customer->description = $request->input('description');
        $customer->password = \Hash::make($request->input('password'));*/

        $customer->setAttributes($request->all());
        $customer->save();


        session()->flash('message', 'Köszönjük a regisztrációt');

        return redirect()->back();
    }

    //show one customer
    public function show($customerId)
    {

        $customer = Customer::find($customerId);
        //$customer = Customer::where('id', $customerId)->first(); null a return , ha nincs

        return view('frontend.customers.show')->with('customer', $customer);
    }

    //edit the customer
    public function edit($customerId)
    {
        $customer = Customer::findOrFail($customerId);

        return view('frontend.customers.edit')->with('customer', $customer);
    }

    //save new registration
    public function update(Request $request, $id)
    {

        $this->validate($request, [
            'name' => 'required',
            'email' => 'required|email|unique:customers,email,' . $request->id,
            'description' => 'required',
            'password' => 'confirmed'
        ]);

        $customer = Customer::findOrFail($id);
        /*$customer->name = $request->input('name');
        $customer->email = $request->input('email');
        $customer->description = $request->input('description');
        $customer->password = \Hash::make($request->input('password'));*/

        $customer->setAttributes($request->all());

        $customer->save();

        session()->flash('message', 'Köszönjük a módosítást');

        return redirect()->back();
    }

    public function destroy(Request $request, $id)
    {

        $customer = Customer::find($id);
        $customer->delete();

        session()->flash('message', 'Törlés megtörtént');

        return redirect()->back();
    }

    public function destroyWithJson($customerId)
    {
        $customer = Customer::findOrFail($customerId);
        $customer->delete();

        return response()->json(['message' => 'Az ügyfél törölve']);
        //return redirect()->route('customers.index');
    }


    public function index2()
    {

        $customer = Customer::find(1);
        $customer->lastUpdated();

        dd($customer->lastUpdated());
        dd($customer->email);

        $customer = Customer::first();
        dd($customer);

        $customers = Customer::all();
        dd($customers);
    }

    public function newCustomer()
    {
        $customer = new Customer();
        $customer->name = 'Elek';
        $customer->leiras = 'beled2';
        $customer->email = 'elek2@elek.hu';
        $customer->password = \Hash::make('123456');
        $customer->save();
    }
}
