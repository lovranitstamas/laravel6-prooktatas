<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Foundation\Auth\User as Authenticatable;

class Note extends Model
{

    //Primary key
    public $primaryKey = 'id';

    public function setAttributes($data)
    {
        $this->content = $data['content'];
        $this->user_id = $data['user_id'];

    }

    public function customer()
    {
        return $this->belongsTo('App\Models\Customer','user_id', 'id');
    }
}
