<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Foundation\Auth\User as Authenticatable;

class Customer extends Authenticatable
{
    public $table = 'customers';

    public function lastUpdated()
    {
        return $this->updated_at->format('Y-m-d');
    }

    public function setAttributes($data)
    {
        $this->name = $data['name'];
        $this->email = $data['email'];
        $this->description = $data['description'];
        /*if($data['password'])    //ha nem üres string */

        if (isset($data['password']) && $data['password']) {
            $this->password = \Hash::make($data['password']);
        }
    }


    public function scopeSearch($query, $data)
    {
        if (isset($data['name']) && $data['name']) {   //$search['name']  = Horvath;
            $query->where('name', 'LIKE', '%' . $data['name'] . '%');
        }

        if (isset($data['email']) && $data['email']) {   //$search['name']  = Horvath;
            $query->where('email', 'LIKE', '%' . $data['email'] . '%');
        }

        if (isset($data['description']) && $data['description']) {   //$search['name']  = Horvath;
            $query->where('description', 'LIKE', '%' . $data['description'] . '%');
        }

        //Customer::where('name', 'LIKE', 'valami')->orWhere('email', 'LIKE', 'másvalami');
    }

    public function scopeFreshRegister($query)
    {
        //a héten regisztráltak
        $date = Carbon::now()->subWeek()->format('Y-m-d');
        $query->where('created_at', '>', $date);
    }

    public function notes()
    {
        return $this->hasMany('App\Models\Note');
    }

}
